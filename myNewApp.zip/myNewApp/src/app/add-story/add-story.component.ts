import { Component, OnInit } from '@angular/core';
import {PokersessionService} from './add-story.service'

@Component({
  templateUrl: './add-story.component.html',
  styleUrls: ['./add-story.component.css']
})
export class AddStoryComponent implements OnInit {
  addStory:any = false;
  storyid:any="";
  description="";
  constructor(private PokersessionService:PokersessionService) { }

  addStoryfn():void{
    debugger
    this.PokersessionService.addStoryfn({ status:'pending',storyId:this.storyid, description: this.description })
      .subscribe(data => {
        console.log(data)
      })
  }

  ngOnInit(): void {
  }

}
