import { Component, OnInit, NgZone, Inject } from '@angular/core';
import { Subscription } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { AppService } from './app.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ISession } from './session';
@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  newMember!: any;
  pageTitle = 'poker session';
  userTitle = '';
  welcome = true;
  addStory=false; 
  pokerSession = false;
  votingScreen=false;
  Http: any;
  filteredProducts: any = [];
  filteredStory:any=[];
  people!: ISession[];
  storage: any;
  data: any;
  constructor(
    public fb: FormBuilder,
    private ngZone: NgZone,
    private router: Router,
    public appService: AppService
  ) { }  
  enterNewSession() {
    debugger;
    this.welcome = false;
    this.pokerSession = true;
    this.appService.enterSession({ memberName: this.userTitle, joined: true })
      .subscribe(data => {
        console.log(data)
      })
      this.loadMember();
      localStorage.setItem("currentMember", this.userTitle);
      }
    loadMember() {
      return this.appService.GetIssues().subscribe((data: {}) => {
        this.filteredProducts = data;
      })
    }
    loadStories(){
      return this.appService.getStory().subscribe((data: {}) => {
        this.filteredStory = data;
      })
    }
  ngOnInit(): void {
    this.loadMember()
    this.loadStories()
  }
}

function currentMember(currentMember: any, arg1: string) {
  throw new Error('Function not implemented.');
}

