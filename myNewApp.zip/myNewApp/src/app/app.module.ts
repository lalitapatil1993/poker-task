import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { SessionComponent } from './session/session.component';
import {HttpClientModule} from '@angular/common/http';
import {AppService} from './app.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule} from '@angular/forms';
import { AddStoryComponent } from './add-story/add-story.component';
import { VotingScreenComponent } from './voting-screen/voting-screen.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    SessionComponent,
    AddStoryComponent,
    VotingScreenComponent
    
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
      RouterModule.forRoot([
        { path: 'app', component: AppComponent },
        { path: '', redirectTo: 'app', pathMatch: 'full' },
        { path: 'session', component:SessionComponent },
        { path:'addStory',component:AddStoryComponent},
        {path:'votingScreen',component:VotingScreenComponent}
    ]),
      BrowserAnimationsModule,
     
  ],
  providers: [AppService,AppComponent,SessionComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
