import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AppService } from './session.service';
import { ISession } from "./session";
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-session',
  templateUrl: './session.component.html',
  styleUrls: ['./session.component.css']
})

export class SessionComponent implements OnInit {
  title = "Poker session";
  memberList = "List of members";
  storyList = "List of stories";
  addUserStory="Add User Story"
  errorMessage = '';
  sub!: Subscription;
  story!: Subscription;
  filteredProducts: any = [];
  products: ISession[] = [];
  filteredStories: any = [];
  welcome: any;
  pokerSession: any;
  closeResult: string = '';
  addStory:any;
  dummyMember:any=[];
  dummyStories:any=[];

  stories: ISession[] = [];


  constructor(private AppService: AppService,private AppComponent:AppComponent) { }

  ngOnInit(): void {    
    this.loadMember();
    this.loadStories();
  }
  loadMember() {
    return this.AppService.GetIssues().subscribe((data: {}) => {
      this.filteredProducts = data;
    })
  }
  loadStories() {
    return this.AppService.GetIssuesStories().subscribe((data: {}) => {
      this.filteredStories = data;
    })
  }
  deleteMember(id: object) {
    console.log('OFFER ID: ' + id);
    this.AppService.deleteMember(id).subscribe(
      () => {
        console.log('Offer Deleted Successfully');
        this.loadMember();
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = <any>err;
      });
  } 
  deleteStory(id:any){
    console.log('OFFER ID: ' + id);
    this.AppService.deleteStory(id).subscribe(
      () => {
        console.log('Offer Deleted Successfully');
        this.loadStories();
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = <any>err;
      });
  }
  statusChange(id: any, storyid: any, status:any,description:any) {
    debugger
    
    let abc= (status =='voted' ? 'voted' :'voting');
      let data = {
        id: id,
        status: abc,
        storyId: storyid,
        description:description,
        name: this.AppComponent.userTitle
      }
      this.AppService.update(id, data).subscribe((response) => {
        this.loadStories();
      }, (error => {

      }));
    
  }  
  enterStory():void{
    this.addStory = true;
    this.pokerSession= false;
    
  }
  distroySession(): void {
    this.dummyMember=this.filteredProducts;
    this.dummyStories= this.filteredStories;
    this.filteredProducts = [];
    this.filteredStories = [];
  }
 
  showModal():void{
    
  }
}
