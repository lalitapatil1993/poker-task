// 
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ISession } from './session';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AppService {
  [x: string]: any;
  // Base url
  baseurl = 'http://localhost:3000/';
  constructor(private http: HttpClient) {}
  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'Pragma':'no-cache'
    }),
  };
  // GET
  GetIssue(memberName: string): Observable<ISession[]> {
    return this.http
      .get<ISession[]>(this.baseurl + 'memberList/' + memberName)
      .pipe(retry(1), catchError(this.errorHandl));
  }
  // GET
  GetIssues(): Observable<ISession[]> {
    return this.http
      .get<ISession[]>(this.baseurl + 'memberList')
      .pipe(retry(1), catchError(this.errorHandl));
  }
  // GET
  GetIssueStory(storyId: number): Observable<ISession[]> {
    return this.http
      .get<ISession[]>(this.baseurl + 'storyList/' + storyId)
      .pipe(retry(1), catchError(this.errorHandl));
  }
  // GET
  GetIssuesStories(): Observable<ISession[]> {
    return this.http
      .get<ISession[]>(this.baseurl + 'storyList/')
      .pipe(retry(1), catchError(this.errorHandl));
  }
  
  deleteMember(id: object):Observable<ISession[]>{         
    console.log('Delete Offer Called');
    return this.http
    .delete<ISession[]>(this.baseurl + 'memberList/' + id)
    .pipe(retry(1), catchError(this.errorHandl));
  }
  deleteStory(id: object):Observable<ISession[]>{         
    console.log('Delete Offer Called');
    return this.http
    .delete<ISession[]>(this.baseurl + 'storyList/' + id)
    .pipe(retry(1), catchError(this.errorHandl));
  }
  update(id: object, data: object): Observable<ISession[]> {
    var app_url=(this.baseurl + 'storyList/' + id);
    return this.http.put<ISession[]>(app_url , data).pipe(
      catchError(this.errorHandl)
    )
  }
  // Error handling
  errorHandl(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(() => {
      return errorMessage;
    });
  }
}