interface IProduct {
  memberName: string,
  online:boolean
}
 interface IStories{
  storyId:Number,
  status:string
}
export interface ISession{
  memberList: Array<IProduct>;
  storyList :Array<IStories>;
}