export interface IStories{
    storyId:Number,
    status:string
  }