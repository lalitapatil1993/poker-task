import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { AppService } from '../app.service';

@Component({
  templateUrl: './voting-screen.component.html',
  styleUrls: ['./voting-screen.component.css']
})
export class VotingScreenComponent implements OnInit {

  votingCards: any = [];
  cardname: any = {};
  fibos: any;
  votingScreen: any = false;
  title = "Submit Estimates";
  count=1;
  storyData:any=[];
  tableData:any=[];
  currentuser:any= localStorage.getItem("currentMember");
  fibonacci_series() {
    var i: any;

    var a = 0, b = 1, f = 1;

    for (i = 2; i <= 10; i++) {

      f = a + b;

      a = b;

      b = f;

      console.log(f);

      this.votingCards.push(f);
      console.log(this.votingCards);
    }

  };
  constructor(private AppComponent:AppComponent,private AppService:AppService) { }
  voting(name:any):void{
    debugger    
    this.count++; 
    alert("vote emitted");
    
  }
  stopVoting(id: object,storyId: any,status: any,description: any){
    debugger
    let data = {
      id: id,
      status: "voted",
      storyId: storyId,
      description:description,
      name: this.AppComponent.userTitle
    }
    this.AppService.update(id, data).subscribe((response) => {
      this.getStory();
    }, (error => {

    }));
  }
  getTableData(){
    return this.AppService.getTableData().subscribe((data: {}) => {
      this.tableData = data;
    })
  }
  getStory(){    
    return this.AppService.getStory().subscribe((data: {}) => {
      this.storyData = data;
    })
    
  }
  stopvoting(){
    debugger
    var result = this.storyData.find((obj: { start: string; }) => {
      return obj.start == "clicked";
    });
  }
  ngOnInit(): void {
    debugger
    this.count=this.count + this.AppComponent.filteredStory.length;
    this.fibonacci_series();
    this.getStory();
  }

}
